var index =
[
    [ "🌟 Возможности", "index.html#autotoc_md1", [
      [ "📊 Комплексный мониторинг", "index.html#autotoc_md2", null ],
      [ "🚀 Умные функции", "index.html#autotoc_md3", null ],
      [ "🌐 Интеграции", "index.html#autotoc_md4", null ]
    ] ],
    [ "🎯 Для кого этот проект?", "index.html#autotoc_md5", null ],
    [ "💡 Почему JXCT?", "index.html#autotoc_md6", null ],
    [ "🛠️ Технические детали", "index.html#autotoc_md7", [
      [ "Оборудование", "index.html#autotoc_md8", null ],
      [ "Производительность", "index.html#autotoc_md9", null ]
    ] ],
    [ "🛠️ Аппаратные требования", "index.html#autotoc_md10", null ],
    [ "🚀 Начало работы", "index.html#autotoc_md11", null ],
    [ "📚 Документация", "index.html#autotoc_md12", null ],
    [ "🌟 Сообщество", "index.html#autotoc_md13", null ],
    [ "📄 Лицензия", "index.html#autotoc_md14", null ]
];