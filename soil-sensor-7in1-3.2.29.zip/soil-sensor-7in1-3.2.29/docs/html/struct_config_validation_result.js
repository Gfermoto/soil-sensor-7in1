var struct_config_validation_result =
[
    [ "errors", "struct_config_validation_result.html#adfe9c7666685cd227d3a2c4d0e10efe1", null ],
    [ "isValid", "struct_config_validation_result.html#ae1533b894732e63a2322865fba65c499", null ]
];