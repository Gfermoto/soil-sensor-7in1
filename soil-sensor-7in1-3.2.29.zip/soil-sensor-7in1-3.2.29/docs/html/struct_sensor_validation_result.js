var struct_sensor_validation_result =
[
    [ "errors", "struct_sensor_validation_result.html#a41444c647d77a9f5f7b4c7d38e2abb8a", null ],
    [ "isValid", "struct_sensor_validation_result.html#acfa046237a82d060e944d05e093d26bf", null ]
];