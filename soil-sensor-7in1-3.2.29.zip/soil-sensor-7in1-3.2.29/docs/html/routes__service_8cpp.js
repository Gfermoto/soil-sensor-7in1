var routes__service_8cpp =
[
    [ "formatUptime", "routes__service_8cpp.html#ab21327c115eef976cb4e8f5f5a94d4c7", null ],
    [ "getApSsid", "routes__service_8cpp.html#af857f35623b29612a3b4cc45dd6fff23", null ],
    [ "getThingSpeakLastError", "routes__service_8cpp.html#ae3f256ffaf18113d28229c8ae013b1f5", null ],
    [ "getThingSpeakLastPublish", "routes__service_8cpp.html#add7f50ba743d6501c1ad5e2dd4985e53", null ],
    [ "navHtml", "routes__service_8cpp.html#ad30c0b8b33e60ccdb13f2e1cc08157c9", null ],
    [ "setupServiceRoutes", "routes__service_8cpp.html#a32c74f47a23de058ee90a43af2dff066", null ],
    [ "currentWiFiMode", "routes__service_8cpp.html#afd1ea40c3b78acfa354aed81da58e582", null ],
    [ "sensorLastError", "routes__service_8cpp.html#acc5319275c2df675d59ff17f862d3e44", null ],
    [ "webServer", "routes__service_8cpp.html#a6385fd6a6118223757bf00a8ba828562", null ]
];