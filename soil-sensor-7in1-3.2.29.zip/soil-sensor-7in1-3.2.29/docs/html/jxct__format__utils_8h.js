var jxct__format__utils_8h =
[
    [ "format_ec", "jxct__format__utils_8h.html#a39b2dedc3670adcf20a62a8d113d2483", null ],
    [ "format_moisture", "jxct__format__utils_8h.html#a3be478cef555484efe62159216f6d470", null ],
    [ "format_npk", "jxct__format__utils_8h.html#abdc9f6cdc05f0aa72eec54b3e904ca7b", null ],
    [ "format_ph", "jxct__format__utils_8h.html#a416ab24406c338058778bbde7c4da152", null ],
    [ "format_temperature", "jxct__format__utils_8h.html#a9a843da2888c9b8014dd9506284f1351", null ],
    [ "formatValue", "jxct__format__utils_8h.html#ac78af75db9fe02059342eed69de396e4", null ]
];