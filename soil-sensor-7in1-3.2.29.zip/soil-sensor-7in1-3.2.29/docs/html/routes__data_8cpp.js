var routes__data_8cpp =
[
    [ "formatValue", "routes__data_8cpp.html#adc35370b803782f896c844976a9ad6ce", null ],
    [ "getApSsid", "routes__data_8cpp.html#af857f35623b29612a3b4cc45dd6fff23", null ],
    [ "navHtml", "routes__data_8cpp.html#ad30c0b8b33e60ccdb13f2e1cc08157c9", null ],
    [ "setupDataRoutes", "routes__data_8cpp.html#aed1136f683a386e56678e05fc3747972", null ],
    [ "timeClient", "routes__data_8cpp.html#ab4cd0eb2684ad54d1d0782f4ff75e07f", null ]
];