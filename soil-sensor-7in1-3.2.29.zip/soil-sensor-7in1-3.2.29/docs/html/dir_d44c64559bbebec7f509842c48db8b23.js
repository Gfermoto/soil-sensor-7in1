var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "debug.h", "debug_8h.html", "debug_8h" ],
    [ "debug_optimized.h", "debug__optimized_8h.html", "debug__optimized_8h" ],
    [ "jxct_config_vars.h", "jxct__config__vars_8h.html", "jxct__config__vars_8h" ],
    [ "jxct_constants.h", "jxct__constants_8h.html", "jxct__constants_8h" ],
    [ "jxct_device_info.h", "jxct__device__info_8h.html", "jxct__device__info_8h" ],
    [ "jxct_format_utils.h", "jxct__format__utils_8h.html", "jxct__format__utils_8h" ],
    [ "jxct_ui_system.h", "jxct__ui__system_8h.html", "jxct__ui__system_8h" ],
    [ "logger.h", "logger_8h.html", "logger_8h" ],
    [ "validation_utils.h", "validation__utils_8h.html", "validation__utils_8h" ],
    [ "version.h", "version_8h.html", "version_8h" ],
    [ "web_routes.h", "web__routes_8h.html", "web__routes_8h" ]
];