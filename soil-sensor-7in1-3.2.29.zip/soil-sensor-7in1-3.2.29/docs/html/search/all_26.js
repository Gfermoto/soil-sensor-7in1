var searchData=
[
  ['этот_20проект_0',['🎯 Для кого этот проект?',['../index.html#autotoc_md5',1,'']]]
];
