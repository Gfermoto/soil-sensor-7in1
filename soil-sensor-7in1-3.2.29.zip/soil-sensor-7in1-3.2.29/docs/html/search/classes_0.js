var searchData=
[
  ['configdata_0',['ConfigData',['../struct_config_data.html',1,'']]],
  ['configvalidationresult_1',['ConfigValidationResult',['../struct_config_validation_result.html',1,'']]]
];
