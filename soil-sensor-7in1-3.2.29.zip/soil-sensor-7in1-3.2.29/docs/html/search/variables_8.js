var searchData=
[
  ['json_5fbuffer_5fsize_0',['JSON_BUFFER_SIZE',['../jxct__constants_8h.html#a3ab6698eff150be75250e5066a32c343',1,'jxct_constants.h']]],
  ['jxct_5fbutton_5fhold_5ftime_5fms_1',['JXCT_BUTTON_HOLD_TIME_MS',['../jxct__constants_8h.html#ad9caf8aea0daab8f3b8499c43ca27186',1,'jxct_constants.h']]],
  ['jxct_5fstatus_5fled_5fpin_2',['JXCT_STATUS_LED_PIN',['../jxct__constants_8h.html#a921d1345eebedb569ba46c07be781d2e',1,'jxct_constants.h']]],
  ['jxct_5fwatchdog_5ftimeout_5fsec_3',['JXCT_WATCHDOG_TIMEOUT_SEC',['../jxct__constants_8h.html#a7954a4e74b56f782bc40acf8db11b6a9',1,'jxct_constants.h']]],
  ['jxct_5fwifi_5fap_5fpass_4',['JXCT_WIFI_AP_PASS',['../jxct__constants_8h.html#a4e8fd5f93ab38700d0ef3e9fb0bcc720',1,'jxct_constants.h']]]
];
