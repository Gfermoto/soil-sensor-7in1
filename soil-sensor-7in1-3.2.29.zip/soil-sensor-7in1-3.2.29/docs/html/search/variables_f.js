var searchData=
[
  ['reset_5fbutton_5fpin_0',['RESET_BUTTON_PIN',['../main_8cpp.html#aaef35518e8271022cf7cfca55d8c86d4',1,'RESET_BUTTON_PIN:&#160;main.cpp'],['../jxct__constants_8h.html#a4a3aea0890a9c7d81ed2b359ee3ae200',1,'RESET_BUTTON_PIN:&#160;jxct_constants.h']]],
  ['reset_5fbutton_5ftask_5fpriority_1',['RESET_BUTTON_TASK_PRIORITY',['../jxct__constants_8h.html#a2748e3aebe921d6d2f1965fb7b71bbfa',1,'jxct_constants.h']]],
  ['reset_5fbutton_5ftask_5fstack_5fsize_2',['RESET_BUTTON_TASK_STACK_SIZE',['../jxct__constants_8h.html#af5ae137d7081e66e1cd43e5c8df7de05',1,'jxct_constants.h']]]
];
