var searchData=
[
  ['error_5fprint_0',['ERROR_PRINT',['../debug_8h.html#aefd58cef04351b40871f9aa0c84a895a',1,'debug.h']]],
  ['error_5fprintf_1',['ERROR_PRINTF',['../debug_8h.html#aa7ede35711728c53eb42c1c5c0def9e7',1,'debug.h']]],
  ['error_5fprintln_2',['ERROR_PRINTLN',['../debug_8h.html#aab934c3f2345fdd7f8ca02ff2c332f60',1,'debug.h']]]
];
