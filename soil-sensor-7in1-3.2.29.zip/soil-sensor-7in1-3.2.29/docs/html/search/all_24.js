var searchData=
[
  ['умные_20функции_0',['🚀 Умные функции',['../index.html#autotoc_md3',1,'']]]
];
