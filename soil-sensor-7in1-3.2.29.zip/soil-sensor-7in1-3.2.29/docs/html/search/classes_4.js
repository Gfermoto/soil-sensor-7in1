var searchData=
[
  ['validationerror_0',['ValidationError',['../struct_validation_error.html',1,'']]],
  ['validationresult_1',['ValidationResult',['../struct_validation_result.html',1,'']]]
];
