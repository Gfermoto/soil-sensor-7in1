var searchData=
[
  ['работы_0',['🚀 Начало работы',['../index.html#autotoc_md11',1,'']]]
];
