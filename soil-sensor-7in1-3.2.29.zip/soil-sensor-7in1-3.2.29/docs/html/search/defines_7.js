var searchData=
[
  ['jxct_5fbuild_5fdate_0',['JXCT_BUILD_DATE',['../version_8h.html#a54c102c9bd71e3382ce683efe7b3407b',1,'version.h']]],
  ['jxct_5fbuild_5ftime_1',['JXCT_BUILD_TIME',['../version_8h.html#aa02b5d2d03e3dbdfc2a4a0bcc8ce2818',1,'version.h']]],
  ['jxct_5ffull_5fversion_5fstring_2',['JXCT_FULL_VERSION_STRING',['../config_8cpp.html#a0096f2930a233d1d076483aa61c5b94f',1,'JXCT_FULL_VERSION_STRING:&#160;config.cpp'],['../version_8h.html#a0096f2930a233d1d076483aa61c5b94f',1,'JXCT_FULL_VERSION_STRING:&#160;version.h']]],
  ['jxct_5fmodbus_5fid_3',['JXCT_MODBUS_ID',['../jxct__config__vars_8h.html#ab3f5a96fb12247f8fe0f1eb350a32d90',1,'jxct_config_vars.h']]],
  ['jxct_5fversion_5fat_5fleast_4',['JXCT_VERSION_AT_LEAST',['../version_8h.html#a3500b43e0da5d3814772835fa8f92963',1,'version.h']]],
  ['jxct_5fversion_5fcode_5',['JXCT_VERSION_CODE',['../version_8h.html#abfca905ae033e33cf0310e0d283552e9',1,'version.h']]],
  ['jxct_5fversion_5fmajor_6',['JXCT_VERSION_MAJOR',['../version_8h.html#a6a112058ddea198337c7a135120d6b21',1,'version.h']]],
  ['jxct_5fversion_5fminor_7',['JXCT_VERSION_MINOR',['../version_8h.html#a6ff229495fbd3dddb40a545ea08dff83',1,'version.h']]],
  ['jxct_5fversion_5fpatch_8',['JXCT_VERSION_PATCH',['../version_8h.html#ae65128d504d49e3657fdbedeea27f3de',1,'version.h']]],
  ['jxct_5fversion_5fstring_9',['JXCT_VERSION_STRING',['../version_8h.html#aba3d86f9adebd869f9dabcde75a28eab',1,'version.h']]]
];
