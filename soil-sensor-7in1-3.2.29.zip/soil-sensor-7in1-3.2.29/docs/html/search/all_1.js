var searchData=
[
  ['addtomovingaverage_0',['addToMovingAverage',['../modbus__sensor_8cpp.html#afa3ddec4a6bc8ee0972ab805e02aad6b',1,'addToMovingAverage(SensorData &amp;data, float temp, float hum, float ec, float ph, float n, float p, float k):&#160;modbus_sensor.cpp'],['../modbus__sensor_8h.html#afa3ddec4a6bc8ee0972ab805e02aad6b',1,'addToMovingAverage(SensorData &amp;data, float temp, float hum, float ec, float ph, float n, float p, float k):&#160;modbus_sensor.cpp']]],
  ['ap_1',['AP',['../wifi__manager_8h.html#ae685142b922ea26aa869f6cb5e17a19ca0fd3f8dd5edc33b28db1162e15e8fcbc',1,'wifi_manager.h']]],
  ['api_5fversion_5fcurrent_2',['API_VERSION_CURRENT',['../jxct__constants_8h.html#ae67763a474ed770ac17a07c9f40ed318',1,'jxct_constants.h']]],
  ['api_5fversion_5fv1_3',['API_VERSION_V1',['../jxct__constants_8h.html#a9736db8fbca9550722fc197649a7b05d',1,'jxct_constants.h']]]
];
