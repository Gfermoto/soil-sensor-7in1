var searchData=
[
  ['n_5fbuffer_0',['n_buffer',['../struct_sensor_data.html#a361f886f983491129d039fc97372fdcb',1,'SensorData']]],
  ['nitrogen_1',['nitrogen',['../struct_sensor_data.html#a129ffaa95987191cf7c405525e156b4d',1,'SensorData']]],
  ['nitrogenconfig_2',['nitrogenConfig',['../struct_home_assistant_config_cache.html#a1648454a3091eae140c338afcd5485e3',1,'HomeAssistantConfigCache']]],
  ['ntpudp_3',['ntpUDP',['../main_8cpp.html#a22f33e7e05df58bb6145bb6e543e232a',1,'main.cpp']]],
  ['ntpupdateinterval_4',['ntpUpdateInterval',['../struct_config_data.html#a2d2106d586c94e91e3d797d77deacdaf',1,'ConfigData']]]
];
