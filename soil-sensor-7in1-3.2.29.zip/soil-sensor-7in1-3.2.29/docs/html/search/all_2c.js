var searchData=
[
  ['📄_20лицензия_0',['📄 Лицензия',['../index.html#autotoc_md14',1,'']]]
];
