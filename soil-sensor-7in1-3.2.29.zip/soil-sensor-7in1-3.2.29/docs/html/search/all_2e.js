var searchData=
[
  ['📚_20документация_0',['📚 Документация',['../index.html#autotoc_md12',1,'']]]
];
