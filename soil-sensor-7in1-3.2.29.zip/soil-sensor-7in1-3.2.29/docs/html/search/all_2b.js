var searchData=
[
  ['💡_20почему_20jxct_0',['💡 Почему JXCT?',['../index.html#autotoc_md6',1,'']]]
];
