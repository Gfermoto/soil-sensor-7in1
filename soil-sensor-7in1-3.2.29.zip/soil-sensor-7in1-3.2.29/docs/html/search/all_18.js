var searchData=
[
  ['возможности_0',['🌟 Возможности',['../index.html#autotoc_md1',1,'']]]
];
