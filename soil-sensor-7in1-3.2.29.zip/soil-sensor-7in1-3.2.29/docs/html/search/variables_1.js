var searchData=
[
  ['buffer_5ffilled_0',['buffer_filled',['../struct_sensor_data.html#acf88a59ba1b4c48bcbe74e853e3ab7e7',1,'SensorData']]],
  ['buffer_5findex_1',['buffer_index',['../struct_sensor_data.html#a0b41fc80d82705a0a7adc521795623d7',1,'SensorData']]]
];
