var searchData=
[
  ['функции_0',['🚀 Умные функции',['../index.html#autotoc_md3',1,'']]]
];
