var searchData=
[
  ['reg_5fcalibration_0',['REG_CALIBRATION',['../modbus__sensor_8h.html#a9b707a93013b08d191303ed584a140d7',1,'modbus_sensor.h']]],
  ['reg_5fconductivity_1',['REG_CONDUCTIVITY',['../modbus__sensor_8h.html#ae4a11435c54c0c61a370f01ad74783dd',1,'modbus_sensor.h']]],
  ['reg_5fdevice_5faddress_2',['REG_DEVICE_ADDRESS',['../modbus__sensor_8h.html#a9261d699774c32e6612b86d5ff383120',1,'modbus_sensor.h']]],
  ['reg_5ferror_5fstatus_3',['REG_ERROR_STATUS',['../modbus__sensor_8h.html#ac264831b378bd2513785f56a63a2cf9a',1,'modbus_sensor.h']]],
  ['reg_5ffirmware_5fversion_4',['REG_FIRMWARE_VERSION',['../modbus__sensor_8h.html#a149baf37365c4dd67e8c37e211fe5afc',1,'modbus_sensor.h']]],
  ['reg_5fnitrogen_5',['REG_NITROGEN',['../modbus__sensor_8h.html#a9f80ba4d6b98c8b586f32a67189637c9',1,'modbus_sensor.h']]],
  ['reg_5fph_6',['REG_PH',['../modbus__sensor_8h.html#a1f0d81a7889405dddfd0740779103c1c',1,'modbus_sensor.h']]],
  ['reg_5fphosphorus_7',['REG_PHOSPHORUS',['../modbus__sensor_8h.html#a6aa33492b3c99407fab5717bf51f3c58',1,'modbus_sensor.h']]],
  ['reg_5fpotassium_8',['REG_POTASSIUM',['../modbus__sensor_8h.html#a2f35ba14a2dedd4527dadfe5df270ecc',1,'modbus_sensor.h']]],
  ['reg_5fsoil_5fmoisture_9',['REG_SOIL_MOISTURE',['../modbus__sensor_8h.html#ae81f2380d8a1a56150fef81dfff25cfc',1,'modbus_sensor.h']]],
  ['reg_5fsoil_5ftemp_10',['REG_SOIL_TEMP',['../modbus__sensor_8h.html#a183e5bdeda520ac205c6fa93a52e1ef4',1,'modbus_sensor.h']]],
  ['reset_5fbutton_5fpin_11',['RESET_BUTTON_PIN',['../wifi__manager_8cpp.html#a56b64973bfd6514570671a2607122199',1,'wifi_manager.cpp']]]
];
