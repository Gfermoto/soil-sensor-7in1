var searchData=
[
  ['dnscache_0',['DNSCache',['../struct_d_n_s_cache.html',1,'']]]
];
