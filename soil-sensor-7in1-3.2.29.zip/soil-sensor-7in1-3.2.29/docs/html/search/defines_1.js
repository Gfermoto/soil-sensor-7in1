var searchData=
[
  ['color_5fblue_0',['COLOR_BLUE',['../logger_8h.html#a23c70d699a5a775bc2e1ebeb8603f630',1,'logger.h']]],
  ['color_5fbold_1',['COLOR_BOLD',['../logger_8h.html#a302607d6f585b7e9ba1c3eab8d2199d5',1,'logger.h']]],
  ['color_5fcyan_2',['COLOR_CYAN',['../logger_8h.html#a82573859711fce56f1aa0a76b18a9b18',1,'logger.h']]],
  ['color_5fgreen_3',['COLOR_GREEN',['../logger_8h.html#afc9149f5de51bd9ac4f5ebbfa153f018',1,'logger.h']]],
  ['color_5fmagenta_4',['COLOR_MAGENTA',['../logger_8h.html#a8deb0beccea721b35bdb1b4f7264fe75',1,'logger.h']]],
  ['color_5fred_5',['COLOR_RED',['../logger_8h.html#ad86358bf19927183dd7b4ae215a29731',1,'logger.h']]],
  ['color_5freset_6',['COLOR_RESET',['../logger_8h.html#a17f760256046df23dd0ab46602f04d02',1,'logger.h']]],
  ['color_5fwhite_7',['COLOR_WHITE',['../logger_8h.html#a9b44987ffdc2af19b635206b94334b69',1,'logger.h']]],
  ['color_5fyellow_8',['COLOR_YELLOW',['../logger_8h.html#a4534b577b74a58b0f4b7be027af664e0',1,'logger.h']]],
  ['config_5fsave_5fdelay_5fms_9',['CONFIG_SAVE_DELAY_MS',['../jxct__config__vars_8h.html#a9ec1b82f0673d93d65a1bd26c7d4a95f',1,'jxct_config_vars.h']]],
  ['critical_5fdebug_5fprint_10',['CRITICAL_DEBUG_PRINT',['../debug__optimized_8h.html#a5bf4ca35d3d5283648b65b646a9d4710',1,'debug_optimized.h']]],
  ['critical_5fdebug_5fprintf_11',['CRITICAL_DEBUG_PRINTF',['../debug__optimized_8h.html#afd5d375337ca9d6bebf6b03bc3b7af43',1,'debug_optimized.h']]],
  ['critical_5fdebug_5fprintln_12',['CRITICAL_DEBUG_PRINTLN',['../debug__optimized_8h.html#aca5049ad9737772e69632c4ffde5661b',1,'debug_optimized.h']]]
];
