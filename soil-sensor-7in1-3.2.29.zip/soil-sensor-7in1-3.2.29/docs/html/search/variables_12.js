var searchData=
[
  ['valid_0',['valid',['../struct_sensor_data.html#a232e987cbc8cfe2b9977416c9e25554f',1,'SensorData']]]
];
