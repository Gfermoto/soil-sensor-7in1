var searchData=
[
  ['primary_0',['PRIMARY',['../jxct__ui__system_8h.html#ae2d5c50fae96a83cc4f5974af78e6943a428429ba9ea83e4841036fb0508fd6dc',1,'jxct_ui_system.h']]]
];
