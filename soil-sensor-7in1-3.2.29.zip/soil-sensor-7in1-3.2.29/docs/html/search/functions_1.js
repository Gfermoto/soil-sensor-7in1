var searchData=
[
  ['addtomovingaverage_0',['addToMovingAverage',['../modbus__sensor_8cpp.html#afa3ddec4a6bc8ee0972ab805e02aad6b',1,'addToMovingAverage(SensorData &amp;data, float temp, float hum, float ec, float ph, float n, float p, float k):&#160;modbus_sensor.cpp'],['../modbus__sensor_8h.html#afa3ddec4a6bc8ee0972ab805e02aad6b',1,'addToMovingAverage(SensorData &amp;data, float temp, float hum, float ec, float ph, float n, float p, float k):&#160;modbus_sensor.cpp']]]
];
