var searchData=
[
  ['почему_20jxct_0',['💡 Почему JXCT?',['../index.html#autotoc_md6',1,'']]],
  ['производительность_1',['Производительность',['../index.html#autotoc_md9',1,'']]],
  ['проект_2',['🎯 Для кого этот проект?',['../index.html#autotoc_md5',1,'']]]
];
