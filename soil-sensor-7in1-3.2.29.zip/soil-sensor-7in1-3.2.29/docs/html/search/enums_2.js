var searchData=
[
  ['messagetype_0',['MessageType',['../jxct__ui__system_8h.html#ac6606ebe91c8ac66a2c314c79f5ab013',1,'jxct_ui_system.h']]]
];
