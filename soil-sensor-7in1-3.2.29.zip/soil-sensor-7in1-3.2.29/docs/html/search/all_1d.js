var searchData=
[
  ['мониторинг_0',['📊 Комплексный мониторинг',['../index.html#autotoc_md2',1,'']]]
];
