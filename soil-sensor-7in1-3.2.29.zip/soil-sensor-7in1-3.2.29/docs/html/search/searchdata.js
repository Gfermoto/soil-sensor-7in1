var indexSectionsWithContent =
{
  0: "_abcdefghijklmnoprstuvwавдиклмнопрстуфэ🌐🌟🌱🎯💡📄📊📚🚀🛠",
  1: "cdhsv",
  2: "cdefjlmrtvw",
  3: "_acdfghilmnprstuvw",
  4: "abcdefhijklmnoprstvw",
  5: "blmw",
  6: "adeilopsw",
  7: "bcdefhijlmorstuw",
  8: "js🌱"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции",
  4: "Переменные",
  5: "Перечисления",
  6: "Элементы перечислений",
  7: "Макросы",
  8: "Страницы"
};

