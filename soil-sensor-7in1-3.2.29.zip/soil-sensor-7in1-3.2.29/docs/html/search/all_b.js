var searchData=
[
  ['k_5fbuffer_0',['k_buffer',['../struct_sensor_data.html#a47cd6d9e8ac34c2eaaf7517790d1f318',1,'SensorData']]]
];
