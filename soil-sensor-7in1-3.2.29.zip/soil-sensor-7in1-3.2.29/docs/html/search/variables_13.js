var searchData=
[
  ['web_5fserver_5ftask_5fpriority_0',['WEB_SERVER_TASK_PRIORITY',['../jxct__constants_8h.html#ab03a887f37e8650b369c91aef844be7b',1,'jxct_constants.h']]],
  ['web_5fserver_5ftask_5fstack_5fsize_1',['WEB_SERVER_TASK_STACK_SIZE',['../jxct__constants_8h.html#ab6cd27ccf48b9e8ab2d17ac4074d4465',1,'jxct_constants.h']]],
  ['webserver_2',['webServer',['../routes__config_8cpp.html#a6385fd6a6118223757bf00a8ba828562',1,'webServer:&#160;routes_config.cpp'],['../routes__service_8cpp.html#a6385fd6a6118223757bf00a8ba828562',1,'webServer:&#160;routes_service.cpp'],['../web__routes_8h.html#a6385fd6a6118223757bf00a8ba828562',1,'webServer:&#160;web_routes.h']]],
  ['wifi_5fconnection_5fattempts_3',['WIFI_CONNECTION_ATTEMPTS',['../jxct__constants_8h.html#ad6f86c92de338fa423acd76cdffc2e1d',1,'jxct_constants.h']]],
  ['wifi_5fconnection_5ftimeout_4',['WIFI_CONNECTION_TIMEOUT',['../jxct__constants_8h.html#ab1991b2b4038578f7511c9c38f8620a9',1,'jxct_constants.h']]],
  ['wifi_5fhostname_5fprefix_5',['WIFI_HOSTNAME_PREFIX',['../jxct__constants_8h.html#ae0b400fec6319db5f57919b2bb6db8f2',1,'jxct_constants.h']]],
  ['wificonnected_6',['wifiConnected',['../wifi__manager_8cpp.html#ac542c876ea54085aa0173a9cd1e3251c',1,'wifiConnected:&#160;wifi_manager.cpp'],['../wifi__manager_8h.html#ac542c876ea54085aa0173a9cd1e3251c',1,'wifiConnected:&#160;wifi_manager.cpp']]]
];
