var searchData=
[
  ['field_0',['field',['../struct_validation_error.html#afe37331a5cad29591a36872c97118ebe',1,'ValidationError']]],
  ['firmware_5fversion_1',['FIRMWARE_VERSION',['../jxct__device__info_8h.html#acf025b054301360475a0ec4542f74ff3',1,'FIRMWARE_VERSION:&#160;jxct_device_info.h'],['../version_8h.html#acf025b054301360475a0ec4542f74ff3',1,'FIRMWARE_VERSION:&#160;version.h']]],
  ['firmware_5fversion_2',['firmware_version',['../struct_sensor_data.html#afde3c50727e3e15ce3850afa8d73eff8',1,'SensorData']]]
];
