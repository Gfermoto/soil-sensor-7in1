var searchData=
[
  ['ota_5fbuffer_5fsize_0',['OTA_BUFFER_SIZE',['../jxct__constants_8h.html#a22264a27d455a1be8245280540e34650',1,'jxct_constants.h']]],
  ['ota_5ftimeout_1',['OTA_TIMEOUT',['../jxct__constants_8h.html#a4e82d246ba3af051580c6dc37dcaf8a3',1,'jxct_constants.h']]],
  ['ota_5fupdate_5furl_5ftemplate_2',['OTA_UPDATE_URL_TEMPLATE',['../jxct__constants_8h.html#ac2eb6652b9b3a0b6a91cf51ae6141291',1,'jxct_constants.h']]],
  ['ota_5fwatchdog_5ftimeout_5fsec_3',['OTA_WATCHDOG_TIMEOUT_SEC',['../jxct__config__vars_8h.html#a34bf95207114d92aae320115352794e5',1,'jxct_config_vars.h']]],
  ['outline_4',['OUTLINE',['../jxct__ui__system_8h.html#ae2d5c50fae96a83cc4f5974af78e6943a6a656275b77dd69c1cc1f49c58859151',1,'jxct_ui_system.h']]]
];
