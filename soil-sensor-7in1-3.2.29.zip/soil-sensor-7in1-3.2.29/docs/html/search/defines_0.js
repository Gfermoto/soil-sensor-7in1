var searchData=
[
  ['boot_5fbutton_0',['BOOT_BUTTON',['../jxct__config__vars_8h.html#ac1268edc13ca85789628d69528560051',1,'jxct_config_vars.h']]],
  ['button_5fhold_5ftime_5fms_1',['BUTTON_HOLD_TIME_MS',['../jxct__config__vars_8h.html#a21bfc357c536666cbacb163b043d27ec',1,'jxct_config_vars.h']]]
];
