var searchData=
[
  ['начало_20работы_0',['🚀 Начало работы',['../index.html#autotoc_md11',1,'']]]
];
