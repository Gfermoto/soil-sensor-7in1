var searchData=
[
  ['ota_5fbuffer_5fsize_0',['OTA_BUFFER_SIZE',['../jxct__constants_8h.html#a22264a27d455a1be8245280540e34650',1,'jxct_constants.h']]],
  ['ota_5ftimeout_1',['OTA_TIMEOUT',['../jxct__constants_8h.html#a4e82d246ba3af051580c6dc37dcaf8a3',1,'jxct_constants.h']]],
  ['ota_5fupdate_5furl_5ftemplate_2',['OTA_UPDATE_URL_TEMPLATE',['../jxct__constants_8h.html#ac2eb6652b9b3a0b6a91cf51ae6141291',1,'jxct_constants.h']]]
];
