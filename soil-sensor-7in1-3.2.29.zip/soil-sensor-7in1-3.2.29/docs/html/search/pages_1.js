var searchData=
[
  ['sensor_0',['🌱 JXCT Soil Sensor',['../index.html',1,'']]],
  ['soil_20sensor_1',['🌱 JXCT Soil Sensor',['../index.html',1,'']]]
];
