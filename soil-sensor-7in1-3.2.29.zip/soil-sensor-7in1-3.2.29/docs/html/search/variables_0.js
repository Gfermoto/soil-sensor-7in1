var searchData=
[
  ['api_5fversion_5fcurrent_0',['API_VERSION_CURRENT',['../jxct__constants_8h.html#ae67763a474ed770ac17a07c9f40ed318',1,'jxct_constants.h']]],
  ['api_5fversion_5fv1_1',['API_VERSION_V1',['../jxct__constants_8h.html#a9736db8fbca9550722fc197649a7b05d',1,'jxct_constants.h']]]
];
