var searchData=
[
  ['ota_5fwatchdog_5ftimeout_5fsec_0',['OTA_WATCHDOG_TIMEOUT_SEC',['../jxct__config__vars_8h.html#a34bf95207114d92aae320115352794e5',1,'jxct_config_vars.h']]]
];
