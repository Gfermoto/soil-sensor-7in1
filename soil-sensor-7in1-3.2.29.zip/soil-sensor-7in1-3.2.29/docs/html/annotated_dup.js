var annotated_dup =
[
    [ "ConfigData", "struct_config_data.html", "struct_config_data" ],
    [ "ConfigValidationResult", "struct_config_validation_result.html", "struct_config_validation_result" ],
    [ "DNSCache", "struct_d_n_s_cache.html", "struct_d_n_s_cache" ],
    [ "HomeAssistantConfigCache", "struct_home_assistant_config_cache.html", "struct_home_assistant_config_cache" ],
    [ "SensorCache", "struct_sensor_cache.html", "struct_sensor_cache" ],
    [ "SensorData", "struct_sensor_data.html", "struct_sensor_data" ],
    [ "SensorValidationResult", "struct_sensor_validation_result.html", "struct_sensor_validation_result" ],
    [ "ValidationError", "struct_validation_error.html", "struct_validation_error" ],
    [ "ValidationResult", "struct_validation_result.html", "struct_validation_result" ]
];