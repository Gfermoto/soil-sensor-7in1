var error__handlers_8cpp =
[
    [ "checkRouteAccess", "error__handlers_8cpp.html#a6d52ae788bd99342b84e28a1af12392b", null ],
    [ "generateValidationErrorResponse", "error__handlers_8cpp.html#a6fe24c5dc21b012791aecd16ab4dad96", null ],
    [ "handleCriticalError", "error__handlers_8cpp.html#a200ff078a206ee5a0b44bc0c5411f3f5", null ],
    [ "handleUploadError", "error__handlers_8cpp.html#a72ddd36cf01d539c0b2575750fa997dc", null ],
    [ "isFeatureAvailable", "error__handlers_8cpp.html#aef0848857422724f7d825dd8a33421b9", null ],
    [ "isFeatureAvailable", "error__handlers_8cpp.html#a195ba09880daef6ce6c14eeceb61feec", null ],
    [ "isRouteAvailable", "error__handlers_8cpp.html#a195f4874889e332e6f540a518d6c51fe", null ],
    [ "logWebRequest", "error__handlers_8cpp.html#a1a62e7c40bff885d97f6018743bec642", null ],
    [ "setupErrorHandlers", "error__handlers_8cpp.html#a833be2e68cb85aa95168dae9c9b128ef", null ],
    [ "validateConfigInput", "error__handlers_8cpp.html#a15eab9f9a3dc97d41a860ab966800fa6", null ]
];