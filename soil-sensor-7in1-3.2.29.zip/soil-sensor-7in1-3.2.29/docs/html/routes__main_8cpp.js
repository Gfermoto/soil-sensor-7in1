var routes__main_8cpp =
[
    [ "setupMainRoutes", "routes__main_8cpp.html#a6a7cf6b6ba01d34721e1a47ea65af867", null ]
];