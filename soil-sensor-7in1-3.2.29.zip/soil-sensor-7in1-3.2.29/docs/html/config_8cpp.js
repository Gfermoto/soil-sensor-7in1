var config_8cpp =
[
    [ "JXCT_FULL_VERSION_STRING", "config_8cpp.html#a0096f2930a233d1d076483aa61c5b94f", null ],
    [ "getDefaultTopic", "config_8cpp.html#a74bdf2231a5ebe05de0f3a0b4c538023", null ],
    [ "getDeviceId", "config_8cpp.html#aa1f35b9688dbf1109436ad91c42901aa", null ],
    [ "isConfigValid", "config_8cpp.html#aeb61f04cd3b4b68e8146d85c447d70d1", null ],
    [ "loadConfig", "config_8cpp.html#ad5ed6ddd9940c0097cc91774056df1c2", null ],
    [ "resetConfig", "config_8cpp.html#a6fa5204bcafe1db397da4a87b1690061", null ],
    [ "saveConfig", "config_8cpp.html#a688d00bbabd28fbaf9e0c50eca3adeae", null ],
    [ "config", "config_8cpp.html#a4a8dd3a2de125b72d4fe6251a0a271b5", null ],
    [ "preferences", "config_8cpp.html#a6ea06cf7b8092a0adaf07614d7ece59d", null ]
];