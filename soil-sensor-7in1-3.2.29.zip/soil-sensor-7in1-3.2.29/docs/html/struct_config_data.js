var struct_config_data =
[
    [ "mqttEnabled", "struct_config_data.html#a9680e7b026b5b2ca4fba7725a14b269a", null ],
    [ "mqttPort", "struct_config_data.html#aa3a6c46c326325f44c5cf551094e4012", null ],
    [ "mqttPublishInterval", "struct_config_data.html#a4cd4bdfc03b67b1a6d0a9c53f3d51148", null ],
    [ "mqttServer", "struct_config_data.html#a6f1dfd087cc2fb57f07e9c906c21318e", null ],
    [ "ntpUpdateInterval", "struct_config_data.html#a2d2106d586c94e91e3d797d77deacdaf", null ],
    [ "password", "struct_config_data.html#a16d6eaf819e4a207fcf52b3038347231", null ],
    [ "sensorReadInterval", "struct_config_data.html#ad39ef7e66372933b6db3bc612b36e149", null ],
    [ "ssid", "struct_config_data.html#ae280e01c917c44f8fdaea8ea803b2398", null ],
    [ "thingSpeakAPIKey", "struct_config_data.html#a38d97f1bfec0f08c3b4ffd4177866660", null ],
    [ "thingSpeakEnabled", "struct_config_data.html#a0297efbded709e911c6a26ec58b4d16f", null ],
    [ "thingspeakInterval", "struct_config_data.html#adb6ae912fb0f894f37e86eaeaf964800", null ]
];