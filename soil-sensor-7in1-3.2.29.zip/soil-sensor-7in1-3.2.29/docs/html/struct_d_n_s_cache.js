var struct_d_n_s_cache =
[
    [ "cachedIP", "struct_d_n_s_cache.html#aef2f96806af2f6e3c4c0fb520bab9341", null ],
    [ "cacheTime", "struct_d_n_s_cache.html#a6e4d95230b1e83b9875e24b5c7ef34c5", null ],
    [ "hostname", "struct_d_n_s_cache.html#a409407f6736dcab313ae2bf019b2d928", null ],
    [ "isValid", "struct_d_n_s_cache.html#a080e8f9905c6577723750f251bde6289", null ]
];