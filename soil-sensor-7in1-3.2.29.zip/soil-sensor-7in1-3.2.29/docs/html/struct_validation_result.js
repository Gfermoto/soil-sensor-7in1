var struct_validation_result =
[
    [ "isValid", "struct_validation_result.html#ae2c6c08be51aa32f2b8991bbcc9c4625", null ],
    [ "message", "struct_validation_result.html#a53fbac7dfa578d7c9532106dbf325eba", null ]
];