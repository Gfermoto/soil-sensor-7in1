var debug_8h =
[
    [ "DEBUG_PRINT", "debug_8h.html#af6551f0b4c3964c3128f808e7bf987c7", null ],
    [ "DEBUG_PRINT_FLOAT", "debug_8h.html#a35b442170ee844eabf46efd41cd58e17", null ],
    [ "DEBUG_PRINT_INT", "debug_8h.html#a604f66fd967d8aca0910fb8affdff324", null ],
    [ "DEBUG_PRINT_VAR", "debug_8h.html#a4c9c6f1fcf820b8f001ceb637faf6e16", null ],
    [ "DEBUG_PRINTF", "debug_8h.html#aa97e8dc28005a1241103bef65128944b", null ],
    [ "DEBUG_PRINTLN", "debug_8h.html#a8e30ff0704664fcb13dabf0c4dc5c8f5", null ],
    [ "ERROR_PRINT", "debug_8h.html#aefd58cef04351b40871f9aa0c84a895a", null ],
    [ "ERROR_PRINTF", "debug_8h.html#aa7ede35711728c53eb42c1c5c0def9e7", null ],
    [ "ERROR_PRINTLN", "debug_8h.html#aab934c3f2345fdd7f8ca02ff2c332f60", null ],
    [ "INFO_PRINT", "debug_8h.html#ada3de6ba49d97903fbf36000cc99d55d", null ],
    [ "INFO_PRINTF", "debug_8h.html#a968ff3408e99f72ecde7095446a3af1e", null ],
    [ "INFO_PRINTLN", "debug_8h.html#a693063ba84ad2119e7f3ea1b97947055", null ]
];