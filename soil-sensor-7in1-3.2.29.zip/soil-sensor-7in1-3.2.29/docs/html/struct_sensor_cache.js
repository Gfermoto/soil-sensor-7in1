var struct_sensor_cache =
[
    [ "data", "struct_sensor_cache.html#a6bd2db19de6e4e64d0c3dbef2a220dd6", null ],
    [ "is_valid", "struct_sensor_cache.html#add741c7682063714899826a20fe363f8", null ],
    [ "timestamp", "struct_sensor_cache.html#ab5ba28cf93b91b1560a5d26926b74a61", null ]
];