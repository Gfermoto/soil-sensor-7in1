var main_8cpp =
[
    [ "handleMQTT", "main_8cpp.html#a926aeaa7d52ebd60e289af8d6ef98600", null ],
    [ "handleWiFi", "main_8cpp.html#aef11d16b4d8e760671e3487b2106b6b2", null ],
    [ "initPreferences", "main_8cpp.html#abb0ddf3422a587580e789235c0503668", null ],
    [ "loadConfig", "main_8cpp.html#ad5ed6ddd9940c0097cc91774056df1c2", null ],
    [ "loop", "main_8cpp.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "resetButtonTask", "main_8cpp.html#a7086f14b298ca33663ff4c10ff47cb4f", null ],
    [ "setup", "main_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "setupModbus", "main_8cpp.html#a0c4410314e55fce67a3c727cb1bf9520", null ],
    [ "setupWiFi", "main_8cpp.html#ad2a97dbe5f144cd247e3b15c6af7c767", null ],
    [ "startFakeSensorTask", "main_8cpp.html#abd277e18147efb1103e91eac01627612", null ],
    [ "startRealSensorTask", "main_8cpp.html#a4f1a431da8f1feb8a64e2c5f887056df", null ],
    [ "lastDataPublishTime", "main_8cpp.html#a6d9eac2bbb6f1354d8abcc8072978a4e", null ],
    [ "lastNtpUpdate", "main_8cpp.html#acc1f621a9291ba211ffa0100abe000ca", null ],
    [ "lastStatusPrint", "main_8cpp.html#a3ddd577fce6fb4aace7649231884939e", null ],
    [ "ntpUDP", "main_8cpp.html#a22f33e7e05df58bb6145bb6e543e232a", null ],
    [ "RESET_BUTTON_PIN", "main_8cpp.html#aaef35518e8271022cf7cfca55d8c86d4", null ],
    [ "STATUS_PRINT_INTERVAL", "main_8cpp.html#ab04f92e3fb6eeb5d01d3cc19653805a1", null ],
    [ "timeClient", "main_8cpp.html#ab4cd0eb2684ad54d1d0782f4ff75e07f", null ]
];