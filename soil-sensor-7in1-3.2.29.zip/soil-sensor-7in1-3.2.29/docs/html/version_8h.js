var version_8h =
[
    [ "JXCT_BUILD_DATE", "version_8h.html#a54c102c9bd71e3382ce683efe7b3407b", null ],
    [ "JXCT_BUILD_TIME", "version_8h.html#aa02b5d2d03e3dbdfc2a4a0bcc8ce2818", null ],
    [ "JXCT_FULL_VERSION_STRING", "version_8h.html#a0096f2930a233d1d076483aa61c5b94f", null ],
    [ "JXCT_VERSION_AT_LEAST", "version_8h.html#a3500b43e0da5d3814772835fa8f92963", null ],
    [ "JXCT_VERSION_CODE", "version_8h.html#abfca905ae033e33cf0310e0d283552e9", null ],
    [ "JXCT_VERSION_MAJOR", "version_8h.html#a6a112058ddea198337c7a135120d6b21", null ],
    [ "JXCT_VERSION_MINOR", "version_8h.html#a6ff229495fbd3dddb40a545ea08dff83", null ],
    [ "JXCT_VERSION_PATCH", "version_8h.html#ae65128d504d49e3657fdbedeea27f3de", null ],
    [ "JXCT_VERSION_STRING", "version_8h.html#aba3d86f9adebd869f9dabcde75a28eab", null ],
    [ "STRINGIFY", "version_8h.html#a6df1d22fb5f09eccc23b9f399670cfd7", null ],
    [ "TOSTRING", "version_8h.html#a9063e80f8777300c93afde6e6f4c9cea", null ],
    [ "DEVICE_MANUFACTURER", "version_8h.html#a83f77c2317b3d28560f91fffca64efea", null ],
    [ "DEVICE_MODEL", "version_8h.html#acd8d2dccf471a5d0cbd070ff1bef8887", null ],
    [ "DEVICE_SW_VERSION", "version_8h.html#aa6399036840a604f6b3bbbf93f7ecd3c", null ],
    [ "FIRMWARE_VERSION", "version_8h.html#acf025b054301360475a0ec4542f74ff3", null ]
];