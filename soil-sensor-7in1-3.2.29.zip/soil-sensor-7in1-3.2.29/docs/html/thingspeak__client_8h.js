var thingspeak__client_8h =
[
    [ "getThingSpeakLastError", "thingspeak__client_8h.html#ae3f256ffaf18113d28229c8ae013b1f5", null ],
    [ "getThingSpeakLastPublish", "thingspeak__client_8h.html#add7f50ba743d6501c1ad5e2dd4985e53", null ],
    [ "sendDataToThingSpeak", "thingspeak__client_8h.html#aaef2ba5628e59244986aa0c0f40b58cf", null ],
    [ "setupThingSpeak", "thingspeak__client_8h.html#af8e20ef000ee56a6aedcc07d88f38f90", null ],
    [ "espClient", "thingspeak__client_8h.html#abd77e757e4b3bb6f1e4b42b21ea9e040", null ]
];