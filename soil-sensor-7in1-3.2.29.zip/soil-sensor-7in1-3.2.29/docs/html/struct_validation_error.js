var struct_validation_error =
[
    [ "field", "struct_validation_error.html#afe37331a5cad29591a36872c97118ebe", null ],
    [ "message", "struct_validation_error.html#a7d8199508641c0ffe90e1b15fe3cc82c", null ]
];