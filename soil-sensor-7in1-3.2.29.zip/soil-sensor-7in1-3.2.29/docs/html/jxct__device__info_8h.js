var jxct__device__info_8h =
[
    [ "getDefaultTopic", "jxct__device__info_8h.html#a74bdf2231a5ebe05de0f3a0b4c538023", null ],
    [ "getDeviceId", "jxct__device__info_8h.html#aa1f35b9688dbf1109436ad91c42901aa", null ],
    [ "FIRMWARE_VERSION", "jxct__device__info_8h.html#acf025b054301360475a0ec4542f74ff3", null ]
];