#ifndef FAKE_SENSOR_H
#define FAKE_SENSOR_H

void startFakeSensorTask();

#endif  // FAKE_SENSOR_H